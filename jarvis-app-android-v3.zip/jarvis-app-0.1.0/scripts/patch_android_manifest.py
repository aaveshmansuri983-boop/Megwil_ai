from pathlib import Path
import sys

manifest = Path("src-tauri/gen/android/app/src/main/AndroidManifest.xml")
if not manifest.exists():
    print(f"Android manifest not found: {manifest}", file=sys.stderr)
    sys.exit(1)

text = manifest.read_text(encoding="utf-8")
permissions = [
    "android.permission.INTERNET",
    "android.permission.RECORD_AUDIO",
]
for permission in permissions:
    tag = f'<uses-permission android:name="{permission}" />'
    if permission not in text:
        text = text.replace("<manifest", "<manifest", 1)
        insert_at = text.find(">", text.find("<manifest")) + 1
        text = text[:insert_at] + "\n    " + tag + text[insert_at:]
manifest.write_text(text, encoding="utf-8")
print("Added INTERNET and RECORD_AUDIO permissions.")
