from pathlib import Path
import json
import sys

required = [
    Path("src-tauri/tauri.conf.json"),
    Path("src-tauri/Cargo.toml"),
    Path("src/index.html"),
    Path("src/main.js"),
]
missing = [str(p) for p in required if not p.is_file()]
if missing:
    print("Missing required Tauri project files: " + ", ".join(missing), file=sys.stderr)
    sys.exit(1)

with Path("src-tauri/tauri.conf.json").open(encoding="utf-8") as f:
    config = json.load(f)
if not config.get("identifier"):
    print("Tauri bundle identifier is missing.", file=sys.stderr)
    sys.exit(1)

print("Tauri source validation passed.")
