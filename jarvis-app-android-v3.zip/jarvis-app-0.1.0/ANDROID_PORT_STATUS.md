# Android Port Status — JARVIS UI + Project-JARVIS

## What is in this repository
- Tauri 2 desktop UI (`src/`, `src-tauri/`)
- Desktop IPC client (`src-tauri/src/ipc.rs`)
- Android APK build workflow (`.github/workflows/android.yml`)

## Verified blockers before a full Android assistant can work

1. **The current Rust IPC client is desktop-oriented.** On Unix targets it uses
   `std::os::unix::net::UnixStream` and expects a JARVIS daemon socket in the
   app data directory. Android can compile Unix APIs, but the daemon is not
   currently packaged or launched inside the Android application.
2. **The Python daemon is not an Android runtime.** Project-JARVIS declares
   Python dependencies including Ollama client, MCP, Vosk, sounddevice,
   Piper TTS and ONNX Runtime. The voice path uses `sounddevice` device
   enumeration and streams. These are not automatically available just
   because the Python source is included in a ZIP.
3. **Ollama is a separate local model service.** The current backend expects an
   Ollama provider by default. A phone build must either connect to a reachable
   remote OpenAI-compatible/Ollama endpoint or implement and validate a
   supported on-device inference runtime.
4. **Android microphone and background lifecycle need native handling.**
   RECORD_AUDIO permission alone is not enough. Runtime permission prompts,
   audio focus, foreground-service rules, notification channel and battery
   restrictions must be implemented and tested on a real Android device.
5. **Desktop-only features need platform guards.** System tray, autostart,
   transparent always-on-top widget windows and desktop file paths need mobile
   alternatives or must be disabled on Android.

## Recommended implementation sequence

- Phase A: Build and install a Tauri Android UI shell; validate on Android 15.
- Phase B: Replace the desktop Unix-socket dependency with a transport abstraction.
  For the first phone prototype use a loopback TCP bridge bound only to
  `127.0.0.1`, with an unpredictable per-launch token and no LAN exposure.
- Phase C: Implement Android-native microphone capture through WebView
  `getUserMedia` or a maintained Tauri Android plugin, including runtime
  permission and lifecycle handling. Do not rely on desktop `sounddevice`.
- Phase D: Decide backend mode: (a) remote backend on a user's own server, or
  (b) an embedded/mobile-compatible backend with dependencies rebuilt for
  Android. Keep API keys in Android secure storage, not in source code.
- Phase E: Port and test STT/TTS, wake-word, memory, MCP tools and parallel
  dispatch individually. Unsupported desktop modules must be reported rather
  than silently omitted.

## Build status
The GitHub Actions workflow prepares Java, Android SDK/NDK and Rust targets,
then asks Tauri to initialize and build an APK. It has **not** been run in this
workspace. A successful UI-shell APK is not proof that the complete JARVIS
daemon, wake word, voice or tools work on Android.

## Local validation performed
- ZIP archive integrity check passed.
- Required Tauri configuration, Rust manifest and frontend entry files were
  inspected.
- No Android SDK, NDK, Rust compiler or Gradle executable was available in
  this workspace, so no APK compilation or device test was possible.
