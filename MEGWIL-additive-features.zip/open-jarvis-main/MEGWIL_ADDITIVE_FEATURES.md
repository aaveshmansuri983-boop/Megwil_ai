# MEGWIL additive feature modules

This update preserves the existing application ID, package namespace, AI task engine,
providers, Graphify schema, and existing screens. It adds source files under
`app/src/main/java/com/openjarvis/extensions/` rather than replacing existing modules.

## Added implementation modules
- `ParallelDispatchEngine.kt`: bounded concurrent execution (maximum five) with per-task success/failure and an executive briefing. It requires the host to pass the real task executor.
- `BrainDumpParser.kt`: splits explicit compound commands into up to five tasks.
- `GlassBrainDumpDialog.kt`: Compose glass-style brain-dump dialog; host must connect its callback to the dispatcher.
- `DeviceControls.kt`: flashlight and music-volume/ringer controls through Android public APIs.
- `CalendarIntents.kt`: opens Android Calendar/Alarm UI for user review and confirmation.
- `PersonalWorkspaceStore.kt`: app-private CRUD storage for notes, todos and drafts.
- `CalculatorEngine.kt`: arithmetic parser for +, -, *, /, parentheses and decimals.
- `HermesMemoryFiles.kt`: initializes and reads/writes user-approved SOUL.md, USER.md and AGENT.md entries in app-private storage.
- `VoiceSessionController.kt`: opt-in voice arming/disarming with a 7.5-second continuation delay. Requires the existing foreground service and microphone permission.
- `VoiceManager.initialize()`: initializes the saved TTS rate for the existing service call.

## Not yet integrated / not verified
The new modules are source implementations, but the existing UI/AgentCore has not yet been fully wired to call every module. In particular, live Graphify-to-SOUL updates, wake-word detection, unified spoken briefing after real AgentCore parallel execution, screenshots via AccessibilityService, and full UI controls remain integration work. Android compilation and device testing have not been run in this environment (no Gradle wrapper or Android SDK was present).
