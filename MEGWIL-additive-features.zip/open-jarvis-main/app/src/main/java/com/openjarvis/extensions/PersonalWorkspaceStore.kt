package com.openjarvis.extensions

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Local private storage for notes, todos and drafts. */
class PersonalWorkspaceStore(context: Context) {
    private val prefs = context.getSharedPreferences("megwil_workspace", Context.MODE_PRIVATE)

    data class Entry(val id: String, val kind: String, val title: String, val body: String, val createdAt: Long)

    @Synchronized fun add(kind: String, title: String, body: String): Entry {
        require(kind in setOf("note", "todo", "draft"))
        require(title.isNotBlank() || body.isNotBlank())
        val entry = Entry(UUID.randomUUID().toString(), kind, title.trim(), body.trim(), System.currentTimeMillis())
        val all = readAll().toMutableList()
        all.add(entry)
        writeAll(all)
        return entry
    }

    @Synchronized fun list(kind: String? = null): List<Entry> =
        readAll().filter { kind == null || it.kind == kind }.sortedByDescending { it.createdAt }

    @Synchronized fun delete(id: String): Boolean {
        val all = readAll()
        val updated = all.filterNot { it.id == id }
        if (updated.size == all.size) return false
        writeAll(updated)
        return true
    }

    private fun readAll(): List<Entry> {
        val array = JSONArray(prefs.getString("entries", "[]"))
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Entry(o.getString("id"), o.getString("kind"), o.optString("title"), o.optString("body"), o.getLong("createdAt"))
        }
    }

    private fun writeAll(entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach {
            array.put(JSONObject().put("id", it.id).put("kind", it.kind).put("title", it.title)
                .put("body", it.body).put("createdAt", it.createdAt))
        }
        prefs.edit().putString("entries", array.toString()).apply()
    }
}
