package com.openjarvis.extensions

/**
 * Conservative compound-command splitter. It splits explicit separators and
 * keeps ordinary commas inside a phrase to avoid breaking names or messages.
 */
object BrainDumpParser {
    fun split(input: String): List<String> {
        return input
            .replace(Regex("(?i)\\s+and then\\s+"), "\n")
            .replace(Regex("(?i)\\s+then\\s+"), "\n")
            .replace(';', '\n')
            .lines()
            .map { it.trim().trim(',', ' ') }
            .filter { it.isNotBlank() }
            .distinct()
            .take(5)
    }
}
