package com.openjarvis.extensions

/** Safe arithmetic parser: supports +, -, *, /, parentheses and decimals only. */
object CalculatorEngine {
    fun evaluate(expression: String): Double {
        require(expression.length <= 256) { "Expression too long" }
        val parser = Parser(expression)
        val value = parser.parseExpression()
        parser.skipSpaces()
        require(parser.atEnd()) { "Unsupported expression" }
        require(value.isFinite()) { "Result is not finite" }
        return value
    }

    private class Parser(private val source: String) {
        private var index = 0
        fun atEnd() = index >= source.length
        fun skipSpaces() { while (!atEnd() && source[index].isWhitespace()) index++ }

        fun parseExpression(): Double {
            var value = parseTerm()
            while (true) {
                skipSpaces()
                value = when {
                    consume('+') -> value + parseTerm()
                    consume('-') -> value - parseTerm()
                    else -> return value
                }
            }
        }

        private fun parseTerm(): Double {
            var value = parseFactor()
            while (true) {
                skipSpaces()
                value = when {
                    consume('*') -> value * parseFactor()
                    consume('/') -> {
                        val divisor = parseFactor()
                        require(divisor != 0.0) { "Division by zero" }
                        value / divisor
                    }
                    else -> return value
                }
            }
        }

        private fun parseFactor(): Double {
            skipSpaces()
            if (consume('+')) return parseFactor()
            if (consume('-')) return -parseFactor()
            if (consume('(')) {
                val value = parseExpression()
                skipSpaces()
                require(consume(')')) { "Missing closing parenthesis" }
                return value
            }
            val start = index
            var dotSeen = false
            while (!atEnd()) {
                val c = source[index]
                if (c.isDigit()) index++
                else if (c == '.' && !dotSeen) { dotSeen = true; index++ }
                else break
            }
            require(index > start) { "Expected a number" }
            return source.substring(start, index).toDouble()
        }

        private fun consume(char: Char): Boolean {
            if (!atEnd() && source[index] == char) { index++; return true }
            return false
        }
    }
}
