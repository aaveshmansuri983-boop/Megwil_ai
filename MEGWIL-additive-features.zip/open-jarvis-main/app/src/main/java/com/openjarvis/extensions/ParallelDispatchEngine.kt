package com.openjarvis.extensions

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Runs independent user-requested subtasks concurrently.
 * The caller supplies the real MEGWIL task executor; this class does not fake results.
 */
class ParallelDispatchEngine(private val maxParallelTasks: Int = 5) {
    data class TaskResult(val index: Int, val command: String, val result: String?, val error: String?)
    data class DispatchResult(val tasks: List<TaskResult>) {
        val succeeded: Int get() = tasks.count { it.error == null }
        val failed: Int get() = tasks.size - succeeded
        fun executiveBriefing(): String = buildString {
            append("MEGWIL completed ")
            append(succeeded)
            append(" of ")
            append(tasks.size)
            append(" tasks.")
            tasks.forEach {
                append("\n")
                append(if (it.error == null) "Done: " else "Failed: ")
                append(it.command)
                append(" — ")
                append(it.result ?: it.error ?: "No result")
            }
        }
    }

    suspend fun dispatch(
        commands: List<String>,
        executor: suspend (String) -> String
    ): DispatchResult = coroutineScope {
        val semaphore = Semaphore(maxParallelTasks.coerceIn(1, 5))
        val results = commands.filter { it.isNotBlank() }.mapIndexed { index, command ->
            async {
                semaphore.withPermit {
                    try {
                        TaskResult(index, command.trim(), executor(command.trim()), null)
                    } catch (t: Throwable) {
                        if (t is kotlinx.coroutines.CancellationException) throw t
                        TaskResult(index, command.trim(), null, t.message ?: "Task failed")
                    }
                }
            }
        }.awaitAll()
        DispatchResult(results.sortedBy { it.index })
    }
}
