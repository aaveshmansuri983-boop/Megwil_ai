package com.openjarvis.extensions

import android.content.Context
import java.io.File

/**
 * Stores editable assistant profile documents inside app-private storage.
 * Updates are explicit; this class never silently rewrites user preferences.
 */
class HermesMemoryFiles(context: Context) {
    private val directory = File(context.filesDir, "hermes").apply { mkdirs() }
    private val defaults = mapOf(
        "SOUL.md" to "# MEGWIL SOUL\n\nDefine assistant principles and boundaries here.\n",
        "USER.md" to "# USER PROFILE\n\nAdd user-approved preferences here.\n",
        "AGENT.md" to "# MEGWIL AGENT\n\nRecord approved operating instructions here.\n"
    )

    fun ensureFiles() {
        defaults.forEach { (name, content) ->
            val file = File(directory, name)
            if (!file.exists()) file.writeText(content)
        }
    }

    fun read(name: String): String {
        require(name in defaults.keys) { "Unsupported memory document" }
        ensureFiles()
        return File(directory, name).readText()
    }

    fun appendApproved(name: String, entry: String) {
        require(name in defaults.keys) { "Unsupported memory document" }
        require(entry.isNotBlank() && entry.length <= 2000) { "Invalid memory entry" }
        ensureFiles()
        File(directory, name).appendText("\n- ${entry.trim()}\n")
    }
}
