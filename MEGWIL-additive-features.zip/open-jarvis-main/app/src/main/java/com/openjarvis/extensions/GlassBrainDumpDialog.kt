package com.openjarvis.extensions

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Reusable glass-style compound-command dialog.
 * Host owns execution and can connect its callback to ParallelDispatchEngine.
 */
@Composable
fun GlassBrainDumpDialog(
    onDismiss: () -> Unit,
    onRunTasks: (List<String>) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val tasks = remember(text) { BrainDumpParser.split(text) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xEE101526),
        titleContentColor = Color(0xFFEAF7FF),
        textContentColor = Color(0xFFD8E8F5),
        title = { Text("MEGWIL • Brain Dump") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Speak or type multiple tasks. Use a new line, semicolon, or “then” between tasks.")
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    label = { Text("Your tasks") }
                )
                Text("Detected tasks: ${tasks.size}/5", color = Color(0xFF66D9EF))
                LazyColumn(modifier = Modifier.heightIn(max = 160.dp)) {
                    itemsIndexed(tasks) { index, task ->
                        Text("${index + 1}. $task", modifier = Modifier.padding(vertical = 3.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = tasks.isNotEmpty(),
                onClick = { onRunTasks(tasks); onDismiss() }
            ) { Text("Run tasks") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
