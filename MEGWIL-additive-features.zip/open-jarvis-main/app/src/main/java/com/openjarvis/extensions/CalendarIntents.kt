package com.openjarvis.extensions

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import java.util.Calendar

/** Uses Android's calendar UI so the user reviews and confirms the event. */
object CalendarIntents {
    fun createEvent(context: Context, title: String, startMillis: Long, endMillis: Long, notes: String? = null) {
        require(title.isNotBlank())
        require(endMillis > startMillis)
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            if (!notes.isNullOrBlank()) putExtra(CalendarContract.Events.DESCRIPTION, notes)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun setAlarm(context: Context, hour: Int, minute: Int, message: String) {
        require(hour in 0..23 && minute in 0..59)
        val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
            putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
            putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, message)
            putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
