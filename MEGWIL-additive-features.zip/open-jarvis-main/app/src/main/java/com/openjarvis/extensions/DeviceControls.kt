package com.openjarvis.extensions

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager

/** Device controls use Android public APIs and report unsupported hardware explicitly. */
class DeviceControls(context: Context) {
    private val appContext = context.applicationContext
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val camera = appContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    fun setFlashlight(enabled: Boolean) {
        val cameraId = camera.cameraIdList.firstOrNull { id ->
            camera.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: throw IllegalStateException("This device has no controllable flashlight")
        camera.setTorchMode(cameraId, enabled)
    }

    fun setMusicVolume(percent: Int) {
        require(percent in 0..100)
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            (max * percent / 100f).toInt().coerceIn(0, max),
            0
        )
    }

    fun setRingerSilent(silent: Boolean) {
        val mode = if (silent) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
        audio.ringerMode = mode
    }

    fun musicVolumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return (audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / max
    }
}
