package com.openjarvis.extensions

import com.openjarvis.voice.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * Opt-in conversational continuation: after a recognized turn, reopen listening
 * after 7.5 seconds while armed. The app must already be running a permitted
 * foreground service and RECORD_AUDIO permission must be granted.
 */
class VoiceSessionController(
    private val voiceManager: VoiceManager,
    private val scope: CoroutineScope
) {
    @Volatile private var armed = false
    private var observer: Job? = null
    private var restartJob: Job? = null

    fun isArmed(): Boolean = armed

    fun arm() {
        if (!voiceManager.isVoiceEnabled()) {
            throw IllegalStateException("Enable voice and grant microphone permission first")
        }
        if (armed) return
        armed = true
        observer = scope.launch {
            voiceManager.state.collect { state ->
                when (state) {
                    is VoiceManager.VoiceState.Result,
                    is VoiceManager.VoiceState.Error -> scheduleContinuation()
                    else -> Unit
                }
            }
        }
        voiceManager.startListening()
    }

    fun disarm() {
        armed = false
        restartJob?.cancel()
        observer?.cancel()
        observer = null
        voiceManager.stopListening()
        voiceManager.resetState()
    }

    private fun scheduleContinuation() {
        restartJob?.cancel()
        restartJob = scope.launch {
            delay(7_500)
            if (armed) {
                voiceManager.resetState()
                voiceManager.startListening()
            }
        }
    }
}
